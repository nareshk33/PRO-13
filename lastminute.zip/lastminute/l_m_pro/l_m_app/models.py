from django.db import models

# Create your models here.

class Flight(models.Model):
    airline = models.CharField(max_length=100)
    origin = models.CharField(max_length=100)
    destination = models.CharField(max_length=100)
    departure_date = models.DateField()
    price = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return f"{self.airline} - {self.origin} to {self.destination}"

class Hotel(models.Model):
    name = models.CharField(max_length=200)
    location = models.CharField(max_length=100)
    check_in_date = models.DateField()
    check_out_date = models.DateField()
    price = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return self.name


class Car(models.Model):
    name = models.CharField(max_length=50)
    car_num = models.TextField()
    pickup_point = models.CharField(max_length=200)
    visite_place = models.CharField(max_length=250)
    drop_point = models.CharField(max_length=200)

    def __str__(self):
        return self.name
