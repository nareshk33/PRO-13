from django.contrib import admin
from .models import Flight, Hotel, Car
# Register your models here.

admin.site.register(Flight)
admin.site.register(Hotel)
admin.site.register(Car)

