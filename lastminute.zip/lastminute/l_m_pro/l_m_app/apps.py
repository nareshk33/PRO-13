from django.apps import AppConfig


class LMAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'l_m_app'
