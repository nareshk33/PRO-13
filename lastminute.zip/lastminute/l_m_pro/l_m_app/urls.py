from rest_framework.routers import DefaultRouter
from .views import FlightViewSet, HotelViewSet, CarViewSet

router = DefaultRouter()
router.register(r'flights', FlightViewSet)
router.register(r'hotels', HotelViewSet)
router.register(r'cars', CarViewSet)

urlpatterns = router.urls
